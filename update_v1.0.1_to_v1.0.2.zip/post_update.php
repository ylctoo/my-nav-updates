<?php
// 更新后处理脚本（可选）
// 例如：清理缓存、更新配置等
// 在此文件中可以直接使用 $conn 数据库连接
// $rootPath 为网站根目录路径

// 示例：清理模板缓存
// array_map('unlink', glob($rootPath . '/template/*/cache/*'));
