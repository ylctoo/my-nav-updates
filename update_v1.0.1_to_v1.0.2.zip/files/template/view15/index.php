<?php
// 模板文件不需要检测安装状态，由根目录index.php统一处理
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title id="pageTitle">活动页面</title>
    <link rel="icon" href="" id="siteFavicon">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background-color: #030804; /* 深黑绿色背景 */
            color: #2bf076; /* 亮绿色主字体 */
        }

        /* 主体内容 */
        .container {
            padding: 15px;
        }

        /* 新增：Banner上方文字样式 */
        .top-notice-box {
letter-spacing: 2px;
            text-align: center;
            margin-bottom: 15px;
            line-height: 1.6;
        }

        .notice-title {
            font-size: 27px;
            font-weight: 900;
            color: #2bf076;
            text-shadow: 0 0 8px rgba(43, 240, 118, 0.6);
            margin-bottom: 4px;
        }

        .notice-sub {
            font-size: 13px;
            color: #2bf076;
            font-weight: bold;
            margin-bottom: 4px;
            word-break: break-all;
        }

        .notice-urls {
            font-size: 13px;
            color: #2bf076;
            font-weight: bold;
            margin-bottom: 4px;
            word-break: break-all;
        }

        /* 顶部横幅 */
        .banner {
            width: 100%;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 20px;
            border: 1px solid #1ec95e;
            box-shadow: 0 0 10px rgba(30, 201, 94, 0.2);
        }
        .banner img {
            width: 100%;
            height: 140px;
            object-fit: cover;
            display: block;
        }

        .banner-tip {
            text-align: center;
            font-size: 15px;
            color: #2bf076;
            font-weight: bold;
            letter-spacing: 2px;
            margin: 10px 0 15px;
            text-shadow: 0 0 8px rgba(43, 240, 118, 0.5);
        }

        /* 列表项样式 */
        .item-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .item {
            background: linear-gradient(180deg, #0a190e 0%, #050d07 100%); /* 深色暗绿渐变卡片 */
            padding: 15px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border: 1px solid #165b2a; /* 荧光绿边框 */
            box-shadow: inset 0 0 5px rgba(43, 240, 118, 0.1);
        }

        .item-content {
            display: flex;
            align-items: center;
            flex: 1;
        }

        .logo-box {
            width: 55px;
            height: 55px;
            background-color: #08140a;
            border-radius: 8px;
            margin-right: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            border: 1px solid #2bf076;
        }
        .logo-box img {
            max-width: 100%;
            max-height: 100%;
            object-fit: cover;
        }

        .text-info {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .item-name {
            font-size: 16px;
            font-weight: bold;
            color: #ffffff; /* 白/淡金色文本 */
            text-shadow: 0 0 2px #2bf076;
        }

        /* QQ号码样式 */
        .qq-number {
            font-size: 15px;
            font-weight: bold;
            color: #2bf076; /* 荧光绿色 */
            letter-spacing: 0.5px;
        }

        /* 注册按钮 */
        .register-btn {
            background: linear-gradient(180deg, #3df785 0%, #15a84b 100%); /* 亮绿渐变按钮 */
            color: #000000; /* 黑色粗体字 */
            border: none;
            padding: 8px 18px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 900;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            box-shadow: 0 0 10px rgba(43, 240, 118, 0.4);
            transition: transform 0.1s ease;
        }
        .register-btn:active {
            transform: scale(0.95);
        }

        /* 底部客服栏 */
        .footer-customer {
            margin-top: 35px;
            text-align: center;
        }
        .customer-title {
            font-size: 16px;
            color: #2bf076;
            margin-bottom: 10px;
            font-weight: bold;
            text-shadow: 0 0 5px rgba(43, 240, 118, 0.3);
        }
        .customer-qq {
            border: 1px solid #2bf076;
            border-radius: 8px;
            padding: 12px 24px;
            background-color: #0a1c0f;
            display: inline-block;
            font-size: 18px;
            font-weight: bold;
            color: #ffffff;
            box-shadow: 0 0 8px rgba(43, 240, 118, 0.2);
        }

        /* 网站Logo */
        .notice-logo {max-width:60px;height:auto;margin:0 auto 8px;display:block}

        /* 版权信息 */
        .copy-footer {text-align:center;padding:15px;font-size:12px;color:#5d8a66;border-top:1px solid #133a1b;margin-top:20px}

        /* 客服浮动按钮 */
        .service-float-btn{position:fixed;right:16px;bottom:20px;z-index:1000;display:flex;flex-direction:column;align-items:flex-end;gap:12px;pointer-events:none}
        .service-toggle{width:50px;height:50px;border-radius:50%;background:linear-gradient(135deg,#2bf076,#15a84b);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 6px 20px rgba(43,240,118,.4);transition:all .3s;position:relative;pointer-events:auto}
        .service-toggle:hover{transform:scale(1.1)}
        .service-toggle svg{width:26px;height:26px;fill:#000}
        .service-badge{position:absolute;top:-4px;right:-4px;min-width:18px;height:18px;padding:0 4px;background:#ff4757;border-radius:50%;color:#fff;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(255,71,87,.5)}
        .service-panel{pointer-events:auto;background:#0a1c0f;border:1px solid #165b2a;border-radius:14px;box-shadow:0 12px 35px rgba(0,0,0,.5);padding:14px;width:260px;opacity:0;visibility:hidden;transform:translateY(12px) scale(.95);transition:all .3s cubic-bezier(.34,1.56,.64,1);transform-origin:bottom right}
        .service-panel.active{opacity:1;visibility:visible;transform:translateY(0) scale(1)}
        .service-panel-header{display:flex;align-items:center;justify-content:space-between;padding-bottom:10px;border-bottom:1px solid #165b2a;margin-bottom:10px}
        .service-panel-title{font-size:15px;font-weight:700;color:#2bf076;margin:0}
        .service-panel-close{width:26px;height:26px;border-radius:50%;background:#0f2b16;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#2bf076;font-size:14px;transition:all .2s}
        .service-list{display:flex;flex-direction:column;gap:8px}
        .service-item{display:flex;align-items:center;gap:10px;padding:8px 10px;background:#08140a;border-radius:10px;transition:all .25s;border:1px solid #0f2b16}
        .service-item:hover{background:#0a1c0f;transform:translateX(3px)}
        .service-item-logo{width:38px;height:38px;border-radius:50%;object-fit:cover;border:2px solid #2bf076}
        .service-item-info{flex:1;min-width:0}
        .service-item-name{font-size:13px;font-weight:700;color:#fff;margin-bottom:2px}
        .service-item-account{font-size:12px;color:#89e2a6;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .service-item-action{display:flex;gap:5px}
        .service-copy-btn,.service-add-btn{padding:5px 10px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:none;transition:all .2s}
        .service-copy-btn{background:linear-gradient(135deg,#2bf076,#15a84b);color:#000}
        .service-copy-btn:hover{box-shadow:0 4px 10px rgba(43,240,118,.4);transform:translateY(-1px)}
        .service-add-btn{background:transparent;color:#2bf076;border:1px solid #2bf076}
        .service-add-btn:hover{background:#2bf076;color:#000}
    </style>
</head>
<body>

    <div class="container">
        <!-- Banner上方文字区 -->
        <div class="top-notice-box">
            <img src="" alt="" class="notice-logo" id="noticeLogo">
            <div class="notice-title" id="noticeTitle"></div>
            <div class="notice-sub" id="noticeSub"></div>
            <div class="notice-urls" id="noticeUrls"></div>

        </div>

        <!-- 顶部横幅 -->
        <div class="banner" id="bannerBox">
            <img src="" alt="" id="bannerImg">
        </div>

        <div class="banner-tip">—— 极力推荐 · 新人必红 ——</div>

        <!-- 列表部分 -->
        <div class="item-list" id="itemList">
        </div>

        <!-- 版权信息 -->
        <div class="copy-footer" id="copyFooter"></div>
    </div>

    <!-- 客服浮动按钮 -->
    <div class="service-float-btn">
        <div class="service-panel" id="servicePanel">
            <div class="service-panel-header">
                <h4 class="service-panel-title">在线客服</h4>
                <button class="service-panel-close" id="servicePanelClose">&times;</button>
            </div>
            <div class="service-list" id="serviceList"></div>
        </div>
        <button class="service-toggle" id="serviceToggle">
            <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
            <span class="service-badge" id="serviceBadge" style="display:none">0</span>
        </button>
    </div>

<script>
(function(){
var API = '/api/public.php';
var data = null;

// ── 工具函数 ──
function esc(s) { if (!s) return ''; var d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

// ── 统计上报 ──
function trackVisit() {
    try {
        var x = new XMLHttpRequest();
        x.open('POST', '/api/stats.php', true);
        x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        x.send('action=visit&template=view15&url=' + encodeURIComponent(window.location.pathname));
    } catch(e) {}
}

function trackClick(linkId, linkName, linkUrl) {
    try {
        var x = new XMLHttpRequest();
        x.open('POST', '/api/stats.php', true);
        x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        x.send('action=click&template=view15&link_id=' + encodeURIComponent(linkId) + '&link_name=' + encodeURIComponent(linkName) + '&link_url=' + encodeURIComponent(linkUrl));
    } catch(e) {}
}

// ── 全局点击委托 ──
document.addEventListener('click', function(e) {
    var t = e.target.closest('[data-link-id]');
    if (t) {
        trackClick(t.getAttribute('data-link-id'), t.getAttribute('data-link-name') || '', t.getAttribute('data-link-url') || '');
    }
});

// ── 应用数据 ──
function applyData(d) {
    data = d;

    // 页面标题 + Favicon
    if (d.siteTitle) {
        document.title = d.siteTitle;
        var pt = document.getElementById('pageTitle');
        if (pt) pt.textContent = d.siteTitle;
    }
    if (d.logoData) {
        var fav = document.getElementById('siteFavicon');
        if (fav) fav.href = d.logoData;
        var nl = document.getElementById('noticeLogo');
        if (nl) { nl.src = d.logoData; nl.style.display = ''; }
    }

    // 顶部公告区
    var nt = document.getElementById('noticeTitle');
    if (nt) nt.textContent = d.siteTitle || '';

    var ns = document.getElementById('noticeSub');
    if (ns) ns.textContent = d.announcementText || '';

    var nu = document.getElementById('noticeUrls');
    if (nu) nu.textContent = d.marqueeText || '';

    // 版权信息
    var cf = document.getElementById('copyFooter');
    if (cf) cf.textContent = d.footerCopy || '';

    // Banner 轮播图
    renderBanner(d.carouselImages || [], d.carouselLinks || []);

    // 列表
    renderItems(d.categories || []);

    // 客服面板
    renderServicePanel(d.contacts || []);
}

// ── 渲染 Banner ──
var curBannerIdx = 0;
var bannerImgs = [];
var bannerLinks = [];

function renderBanner(images, links) {
    bannerImgs = images;
    bannerLinks = links;
    var box = document.getElementById('bannerBox');
    var img = document.getElementById('bannerImg');

    if (!box || !img) return;
    if (bannerImgs.length === 0) { box.style.display = 'none'; return; }
    box.style.display = '';

    curBannerIdx = 0;
    updateBanner();

    // 自动切换
    if (bannerImgs.length > 1) {
        setInterval(function() {
            curBannerIdx = (curBannerIdx + 1) % bannerImgs.length;
            updateBanner();
        }, 4000);
    }
}

function updateBanner() {
    var img = document.getElementById('bannerImg');
    if (!img || bannerImgs.length === 0) return;
    img.src = bannerImgs[curBannerIdx];
    img.alt = '';
    // 点击跳转
    var box = document.getElementById('bannerBox');
    if (bannerLinks[curBannerIdx]) {
        box.style.cursor = 'pointer';
        box.onclick = function() { window.open(bannerLinks[curBannerIdx], '_blank'); };
    } else {
        box.style.cursor = 'default';
        box.onclick = null;
    }
}

// ── 渲染列表（来自 links.php 的数据）──
function renderItems(categories) {
    var list = document.getElementById('itemList');
    if (!list) return;

    var html = '';
    for (var ci = 0; ci < categories.length; ci++) {
        var cat = categories[ci];
        var items = cat.items || [];
        for (var ii = 0; ii < items.length; ii++) {
            var item = items[ii];
            var imgSrc = item.avatar || '';
            var btnText = item.buttonText || '注册';
            html += '<div class="item">' +
                '<div class="item-content">' +
                    '<div class="logo-box">' +
                        (imgSrc ? '<img src="' + esc(imgSrc) + '" alt="' + esc(item.title || '') + '">' : '') +
                    '</div>' +
                    '<div class="text-info">' +
                        '<span class="item-name">' + esc(item.title || '') + '</span>' +
                        '<div class="qq-number">' + esc(item.description || '') + '</div>' +
                    '</div>' +
                '</div>' +
                '<a href="' + esc(item.link || '#') + '" class="register-btn" target="_blank" data-link-id="' + esc(item.id || '') + '" data-link-name="' + esc(item.title || '') + '" data-link-url="' + esc(item.link || '') + '">' + esc(btnText) + '</a>' +
            '</div>';
        }
    }

    if (!html) {
        html = '<div style="text-align:center;padding:30px;color:#89e2a6;">暂无数据</div>';
    }
    list.innerHTML = html;
}

// ── 客服面板 ──
function renderServicePanel(contacts) {
    var list = document.getElementById('serviceList');
    var badge = document.getElementById('serviceBadge');
    if (!list) return;
    if (!contacts || !contacts.length) {
        list.innerHTML = '<div style="text-align:center;color:#5d8a66;padding:15px">暂无联系方式</div>';
        if (badge) badge.style.display = 'none';
        return;
    }
    if (badge) { badge.textContent = contacts.length; badge.style.display = ''; }
    list.innerHTML = contacts.map(function(c) {
        var name = c.name || '';
        var val = c.value || '';
        var icon = c.icon || '';
        var link = c.link || '#';
        var iconHtml = icon
            ? '<img src="' + esc(icon) + '" alt="" class="service-item-logo" onerror="this.style.display=\'none\'">'
            : '<div class="service-item-logo" style="display:flex;align-items:center;justify-content:center;font-size:18px;background:#0f2b16">' + esc(name.charAt(0)) + '</div>';
        return '<div class="service-item">' + iconHtml +
            '<div class="service-item-info"><div class="service-item-name">' + esc(name) + '</div><div class="service-item-account">' + esc(val) + '</div></div>' +
            '<div class="service-item-action"><button class="service-copy-btn" data-val="' + esc(val).replace(/"/g, '&quot;') + '">复制</button><button class="service-add-btn" onclick="window.open(\'' + esc(link) + '\',\'_blank\')">添加</button></div></div>';
    }).join('');
    list.querySelectorAll('.service-copy-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var v = this.dataset.val, self = this;
            if (navigator.clipboard) {
                navigator.clipboard.writeText(v).then(function() { self.textContent = '已复制'; self.style.background = '#52c41a'; setTimeout(function() { self.textContent = '复制'; self.style.background = ''; }, 1500); }).catch(function() { fallbackCopy2(v, self); });
            } else { fallbackCopy2(v, self); }
        });
    });
}

function fallbackCopy2(text, btn) {
    var ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); btn.textContent = '已复制'; btn.style.background = '#52c41a'; } catch(e) { btn.textContent = '失败'; }
    setTimeout(function() { btn.textContent = '复制'; btn.style.background = ''; document.body.removeChild(ta); }, 1500);
}

// ── 客服面板切换 ──
(function() {
    var t = document.getElementById('serviceToggle');
    var p = document.getElementById('servicePanel');
    var c = document.getElementById('servicePanelClose');
    if (!t || !p) return;
    t.addEventListener('click', function() { p.classList.toggle('active'); });
    if (c) c.addEventListener('click', function() { p.classList.remove('active'); });
    document.addEventListener('click', function(e) { if (!p.contains(e.target) && !t.contains(e.target)) p.classList.remove('active'); });
})();

// ── 初始化 ──
fetch(API)
    .then(function(r) { return r.json(); })
    .then(function(d) {
        if (d) applyData(d);
        trackVisit();
    })
    .catch(function(err) {
        console.error('数据加载失败:', err);
    });

})();
</script>
</body>
</html>

更新成功

