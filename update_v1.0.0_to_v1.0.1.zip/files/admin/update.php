<?php
/**
 * 系统更新管理页面
 * 功能：检测更新、下载更新包、自动备份、安装更新、更新历史
 */
include('comm.php');
checkLogin();

// 仅超级管理员可访问
if (!isSuperAdmin()) {
    header('Location: index.php');
    exit();
}

$conn = getDBConnection();

// 确保必要表和字段存在
ensureSystemVersionColumn($conn);
ensureUpdateLogTable($conn);

// 获取当前版本
$result = mysqli_query($conn, "SELECT system_version FROM settings LIMIT 1");
$settings = mysqli_fetch_assoc($result);
$currentVersion = isset($settings['system_version']) && !empty($settings['system_version'])
    ? $settings['system_version']
    : SYSTEM_VERSION;

$message = '';
$messageType = ''; // success / error / info
$updateAvailable = false;
$remoteInfo = null;

// ==================== 操作处理 ====================

// 1. 检测更新
if (isset($_GET['action']) && $_GET['action'] == 'check') {
    $remoteInfo = fetchRemoteUpdateInfo();
    if (isset($remoteInfo['error'])) {
        $message = $remoteInfo['error'];
        $messageType = 'error';
    } elseif (isset($remoteInfo['version'])) {
        $cmp = versionCompare($remoteInfo['version'], $currentVersion);
        if ($cmp > 0) {
            $updateAvailable = true;
            // 检查最低版本要求
            if (isset($remoteInfo['min_version']) && versionCompare($currentVersion, $remoteInfo['min_version']) < 0) {
                $message = '当前版本过低，无法直接升级到 v' . $remoteInfo['version']
                         . '，请先升级到 v' . $remoteInfo['min_version'] . ' 或更高版本';
                $messageType = 'error';
                $updateAvailable = false;
            } else {
                $message = '发现新版本 v' . $remoteInfo['version'] . '，可以更新！';
                $messageType = 'info';
            }
        } elseif ($cmp == 0) {
            $message = '当前已是最新版本 v' . $currentVersion;
            $messageType = 'success';
        } else {
            $message = '远程版本 (v' . $remoteInfo['version'] . ') 低于当前版本 (v' . $currentVersion . ')，无需更新';
            $messageType = 'info';
        }
    } else {
        $message = '更新信息格式不正确';
        $messageType = 'error';
    }
}

// 2. 执行自动更新
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'install') {
    $updateUrl = isset($_POST['update_url']) ? trim($_POST['update_url']) : '';
    $expectedMd5 = isset($_POST['update_md5']) ? trim($_POST['update_md5']) : '';
    $targetVersion = isset($_POST['target_version']) ? trim($_POST['target_version']) : '';
    
    if (empty($updateUrl)) {
        $message = '更新包地址不能为空';
        $messageType = 'error';
    } else {
        $rootPath = dirname(__DIR__);
        $tmpZip = $rootPath . '/temp_update_' . time() . '.zip';
        $extractDir = $rootPath . '/temp_update_extract_' . time();
        $backupDir = $rootPath . '/backup/' . date('Ymd') . '_' . date('His');
        
        $stepMessage = [];
        $allSuccess = true;
        
        // 步骤1: 下载更新包
        $stepMessage[] = '正在下载更新包...';
        $ctx = stream_context_create([
            'http' => [
                'timeout' => 60,
                'user_agent' => 'NavigationSystem-Update/1.0',
                'ignore_errors' => true
            ],
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false
            ]
        ]);
        
        $zipContent = @file_get_contents($updateUrl, false, $ctx);
        if ($zipContent === false || strlen($zipContent) < 100) {
            $stepMessage[] = '下载失败：无法获取更新包，请检查URL是否正确';
            $allSuccess = false;
        } else {
            $stepMessage[] = '下载完成 (' . round(strlen($zipContent) / 1024, 1) . ' KB)';
            
            // 步骤2: MD5校验
            if (!empty($expectedMd5)) {
                $actualMd5 = md5($zipContent);
                if (strtolower($actualMd5) !== strtolower($expectedMd5)) {
                    $stepMessage[] = 'MD5校验失败！期望: ' . $expectedMd5 . '，实际: ' . $actualMd5;
                    $allSuccess = false;
                } else {
                    $stepMessage[] = 'MD5校验通过';
                }
            } else {
                $stepMessage[] = '跳过MD5校验（未提供校验值）';
            }
            
            if ($allSuccess) {
                // 保存ZIP文件
                if (file_put_contents($tmpZip, $zipContent) === false) {
                    $stepMessage[] = '保存更新包失败，请检查目录写入权限';
                    $allSuccess = false;
                } else {
                    $stepMessage[] = '更新包已保存';
                    
                    // 步骤3: 解压更新包
                    $zip = new ZipArchive();
                    if ($zip->open($tmpZip) !== true) {
                        $stepMessage[] = '解压失败：更新包损坏或格式不正确';
                        $allSuccess = false;
                    } else {
                        // 读取 update_info.json
                        $infoJson = $zip->getFromName('update_info.json');
                        $packageInfo = $infoJson ? json_decode($infoJson, true) : [];
                        
                        // 检查是否有 files/ 目录
                        $fileList = [];
                        $hasFiles = false;
                        for ($i = 0; $i < $zip->numFiles; $i++) {
                            $name = $zip->getNameIndex($i);
                            if (strpos($name, 'files/') === 0 && $name !== 'files/') {
                                $hasFiles = true;
                                $fileList[] = substr($name, 6); // 去掉 'files/' 前缀
                            }
                        }
                        
                        if (!$hasFiles) {
                            $stepMessage[] = '更新包中没有 files/ 目录，无需覆盖文件';
                        } else {
                            // 步骤4: 备份文件
                            $stepMessage[] = '正在备份 ' . count($fileList) . ' 个文件...';
                            $backedUp = backupFiles($rootPath, $backupDir, $fileList);
                            $stepMessage[] = '已备份 ' . count($backedUp) . ' 个文件到 backup/' . basename($backupDir);
                            
                            // 步骤5: 解压覆盖
                            $stepMessage[] = '正在解压更新文件...';
                            if ($zip->extractTo($extractDir)) {
                                $overwriteCount = 0;
                                foreach ($fileList as $file) {
                                    $src = rtrim($extractDir, '/') . '/files/' . ltrim($file, '/');
                                    $dst = rtrim($rootPath, '/') . '/' . ltrim($file, '/');
                                    if (file_exists($src)) {
                                        $dstDir = dirname($dst);
                                        if (!is_dir($dstDir)) {
                                            mkdir($dstDir, 0777, true);
                                        }
                                        if (copy($src, $dst)) {
                                            $overwriteCount++;
                                        }
                                    }
                                }
                                $stepMessage[] = '已覆盖 ' . $overwriteCount . ' 个文件';
                            } else {
                                $stepMessage[] = '解压失败，正在回滚...';
                                // 回滚：从备份恢复
                                foreach ($backedUp as $file) {
                                    $src = rtrim($backupDir, '/') . '/' . ltrim($file, '/');
                                    $dst = rtrim($rootPath, '/') . '/' . ltrim($file, '/');
                                    if (file_exists($src)) {
                                        copy($src, $dst);
                                    }
                                }
                                $stepMessage[] = '已回滚所有文件';
                                $allSuccess = false;
                            }
                        }
                        
                        // 步骤6: 执行SQL
                        $sqlContent = $zip->getFromName('update.sql');
                        if ($sqlContent && trim($sqlContent) !== '' && trim($sqlContent) !== '-- No SQL changes') {
                            $sqlExecuted = true;
                            $sqlStatements = array_filter(
                                array_map('trim', explode(';', $sqlContent))
                            );
                            $sqlCount = 0;
                            foreach ($sqlStatements as $stmt) {
                                if (!empty($stmt) && strtoupper(substr($stmt, 0, 2)) !== '--') {
                                    if (@mysqli_query($conn, $stmt)) {
                                        $sqlCount++;
                                    } else {
                                        $stepMessage[] = 'SQL执行警告: ' . mysqli_error($conn) . ' (语句: ' . substr($stmt, 0, 80) . '...)';
                                    }
                                }
                            }
                            if ($sqlCount > 0) {
                                $stepMessage[] = '已执行 ' . $sqlCount . ' 条SQL语句';
                            }
                        } else {
                            $sqlExecuted = false;
                            $stepMessage[] = '无需数据库变更';
                        }
                        
                        // 步骤7: 执行post_update脚本
                        $postScript = $zip->getFromName('post_update.php');
                        if ($postScript && trim($postScript) !== '') {
                            $postFile = $extractDir . '/post_update.php';
                            file_put_contents($postFile, $postScript);
                            try {
                                include($postFile);
                                $stepMessage[] = '已执行更新后处理脚本';
                            } catch (Exception $e) {
                                $stepMessage[] = '更新后处理脚本执行异常: ' . $e->getMessage();
                            }
                            @unlink($postFile);
                        }
                        
                        $zip->close();
                        
                        // 步骤8: 更新版本号
                        if ($allSuccess && !empty($targetVersion)) {
                            $escapedVer = mysqli_real_escape_string($conn, $targetVersion);
                            if (mysqli_query($conn, "UPDATE settings SET system_version = '$escapedVer'")) {
                                $stepMessage[] = '版本号已更新为 v' . $targetVersion;
                            }
                        }
                    }
                    
                    // 清理临时文件
                    @unlink($tmpZip);
                    if (is_dir($extractDir)) {
                        deleteDirectory($extractDir);
                    }
                }
            }
        }
        
        // 记录更新日志
        $logMessage = mysqli_real_escape_string($conn, implode("\n", $stepMessage));
        $status = $allSuccess ? 'success' : 'failed';
        $fromVer = mysqli_real_escape_string($conn, $currentVersion);
        $toVer = mysqli_real_escape_string($conn, $targetVersion ?: '');
        $backupPath = mysqli_real_escape_string($conn, 'backup/' . basename($backupDir));
        $ip = mysqli_real_escape_string($conn, $_SERVER['REMOTE_ADDR'] ?? '');
        $fileCnt = isset($fileList) ? count($fileList) : 0;
        $sqlFlag = isset($sqlExecuted) && $sqlExecuted ? 1 : 0;
        
        mysqli_query($conn, "INSERT INTO update_log (from_version, to_version, status, log_message, file_count, sql_executed, backup_path, ip_address)
            VALUES ('$fromVer', '$toVer', '$status', '$logMessage', $fileCnt, $sqlFlag, '$backupPath', '$ip')");
        
        if ($allSuccess) {
            $message = '更新成功！' . "\n" . implode("\n", $stepMessage);
            $messageType = 'success';
            // 刷新当前版本
            $currentVersion = $targetVersion ?: $currentVersion;
        } else {
            $message = '更新过程中出现问题：' . "\n" . implode("\n", $stepMessage);
            $messageType = 'error';
        }
    }
}

// 3. 手动上传更新包
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'upload') {
    if (isset($_FILES['update_package']) && $_FILES['update_package']['error'] == 0) {
        $rootPath = dirname(__DIR__);
        $extractDir = $rootPath . '/temp_update_upload_' . time();
        $backupDir = $rootPath . '/backup/' . date('Ymd') . '_' . date('His');
        
        $stepMessage = [];
        $allSuccess = true;
        
        $tmpZip = $_FILES['update_package']['tmp_name'];
        
        $zip = new ZipArchive();
        if ($zip->open($tmpZip) !== true) {
            $message = '上传的更新包损坏或格式不正确';
            $messageType = 'error';
            $allSuccess = false;
        } else {
            $infoJson = $zip->getFromName('update_info.json');
            $packageInfo = $infoJson ? json_decode($infoJson, true) : [];
            $targetVersion = isset($packageInfo['version']) ? $packageInfo['version'] : '';
            
            $stepMessage[] = '上传成功，解析更新包...';
            
            $fileList = [];
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $name = $zip->getNameIndex($i);
                if (strpos($name, 'files/') === 0 && $name !== 'files/') {
                    $fileList[] = substr($name, 6);
                }
            }
            
            if (!empty($fileList)) {
                $stepMessage[] = '正在备份 ' . count($fileList) . ' 个文件...';
                $backedUp = backupFiles($rootPath, $backupDir, $fileList);
                $stepMessage[] = '已备份 ' . count($backedUp) . ' 个文件';
                
                if ($zip->extractTo($extractDir)) {
                    $overwriteCount = 0;
                    foreach ($fileList as $file) {
                        $src = rtrim($extractDir, '/') . '/files/' . ltrim($file, '/');
                        $dst = rtrim($rootPath, '/') . '/' . ltrim($file, '/');
                        if (file_exists($src)) {
                            $dstDir = dirname($dst);
                            if (!is_dir($dstDir)) {
                                mkdir($dstDir, 0777, true);
                            }
                            if (copy($src, $dst)) {
                                $overwriteCount++;
                            }
                        }
                    }
                    $stepMessage[] = '已覆盖 ' . $overwriteCount . ' 个文件';
                }
            } else {
                $stepMessage[] = '无文件变更';
            }
            
            // 执行SQL
            $sqlContent = $zip->getFromName('update.sql');
            if ($sqlContent && trim($sqlContent) !== '' && trim($sqlContent) !== '-- No SQL changes') {
                $sqlStatements = array_filter(array_map('trim', explode(';', $sqlContent)));
                $sqlCount = 0;
                foreach ($sqlStatements as $stmt) {
                    if (!empty($stmt) && strtoupper(substr($stmt, 0, 2)) !== '--') {
                        if (@mysqli_query($conn, $stmt)) {
                            $sqlCount++;
                        }
                    }
                }
                if ($sqlCount > 0) {
                    $stepMessage[] = '已执行 ' . $sqlCount . ' 条SQL语句';
                    $sqlExecuted = true;
                }
            } else {
                $sqlExecuted = false;
            }
            
            // post_update 脚本
            $postScript = $zip->getFromName('post_update.php');
            if ($postScript && trim($postScript) !== '') {
                $postFile = $extractDir . '/post_update.php';
                file_put_contents($postFile, $postScript);
                try {
                    include($postFile);
                    $stepMessage[] = '已执行更新后处理脚本';
                } catch (Exception $e) {
                    $stepMessage[] = '后处理异常: ' . $e->getMessage();
                }
            }
            
            $zip->close();
            
            // 更新版本号
            if ($allSuccess && !empty($targetVersion)) {
                $escapedVer = mysqli_real_escape_string($conn, $targetVersion);
                mysqli_query($conn, "UPDATE settings SET system_version = '$escapedVer'");
                $stepMessage[] = '版本号已更新为 v' . $targetVersion;
                $currentVersion = $targetVersion;
            }
            
            // 清理
            if (is_dir($extractDir)) {
                deleteDirectory($extractDir);
            }
            
            // 记录日志
            $logMessage = mysqli_real_escape_string($conn, implode("\n", $stepMessage));
            $fromVer = mysqli_real_escape_string($conn, $currentVersion);
            $toVer = mysqli_real_escape_string($conn, $targetVersion);
            $backupPathEsc = mysqli_real_escape_string($conn, 'backup/' . basename($backupDir));
            $ip = mysqli_real_escape_string($conn, $_SERVER['REMOTE_ADDR'] ?? '');
            $fileCnt = count($fileList);
            $sqlFlag = isset($sqlExecuted) && $sqlExecuted ? 1 : 0;
            
            mysqli_query($conn, "INSERT INTO update_log (from_version, to_version, status, log_message, file_count, sql_executed, backup_path, ip_address)
                VALUES ('$fromVer', '$toVer', 'success', '$logMessage', $fileCnt, $sqlFlag, '$backupPathEsc', '$ip')");
            
            $message = '手动更新完成！' . "\n" . implode("\n", $stepMessage);
            $messageType = 'success';
        }
    } else {
        $message = '请选择要上传的更新包文件';
        $messageType = 'error';
    }
}

// ==================== 获取更新历史 ====================
$historyResult = mysqli_query($conn, "SELECT * FROM update_log ORDER BY id DESC LIMIT 20");

// 辅助函数：递归删除目录
function deleteDirectory($dir) {
    if (!is_dir($dir)) return;
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;
        $path = $dir . '/' . $item;
        if (is_dir($path)) {
            deleteDirectory($path);
        } else {
            @unlink($path);
        }
    }
    @rmdir($dir);
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系统更新</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
renderSidebar('update');
renderTopbar('系统更新');
?>
    <div class="content">
        <?php if ($message): ?>
        <div class="alert alert-<?php echo $messageType == 'error' ? 'error' : ($messageType == 'success' ? 'success' : 'info'); ?>">
            <?php echo nl2br(htmlOutput($message)); ?>
        </div>
        <?php endif; ?>

        <!-- 版本信息卡片 -->
        <div class="update-version-cards">
            <div class="update-card">
                <div class="update-card-label">当前版本</div>
                <div class="update-card-version">v<?php echo htmlOutput($currentVersion); ?></div>
                <div class="update-card-desc">已安装版本</div>
            </div>
            <div class="update-card-arrow">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="32" height="32">
                    <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
                </svg>
            </div>
            <div class="update-card <?php echo $updateAvailable ? 'update-card-new' : ''; ?>">
                <div class="update-card-label">最新版本</div>
                <div class="update-card-version">
                    <?php
                    if ($remoteInfo && isset($remoteInfo['version'])) {
                        echo 'v' . htmlOutput($remoteInfo['version']);
                    } elseif (isset($remoteInfo['error'])) {
                        echo '---';
                    } else {
                        echo '---';
                    }
                    ?>
                </div>
                <div class="update-card-desc">
                    <?php
                    if ($updateAvailable) {
                        echo '<span style="color: var(--success);">有新版本可用</span>';
                    } elseif ($remoteInfo && isset($remoteInfo['version'])) {
                        echo '已是最新';
                    } else {
                        echo '点击检测';
                    }
                    ?>
                </div>
            </div>
        </div>

        <!-- 操作区 -->
        <div class="card" style="margin-top: 24px;">
            <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
                <span style="font-weight: 600;">更新操作</span>
                <span style="font-size: 12px; color: var(--text-secondary);">
                    更新服务器: <?php echo (UPDATE_API_URL && strpos(UPDATE_API_URL, 'YOUR_USERNAME') === false) ? '已配置' : '<span style="color: var(--warning);">未配置</span>'; ?>
                </span>
            </div>
            <div class="card-body">
                <!-- 在线更新 -->
                <div class="update-section">
                    <div class="update-section-title">在线更新</div>
                    <p class="update-section-desc">连接远程服务器检测是否有新版本可用。</p>
                    <div class="btn-group" style="margin-top: 12px;">
                        <a href="update.php?action=check" class="btn btn-primary">
                            <?php echo iconSVG('refresh'); ?> 检测更新
                        </a>
                        <?php if ($updateAvailable && $remoteInfo && isset($remoteInfo['download_url'])): ?>
                        <form method="post" style="display: inline;">
                            <input type="hidden" name="action" value="install">
                            <input type="hidden" name="update_url" value="<?php echo htmlOutput($remoteInfo['download_url']); ?>">
                            <input type="hidden" name="update_md5" value="<?php echo isset($remoteInfo['md5']) ? htmlOutput($remoteInfo['md5']) : ''; ?>">
                            <input type="hidden" name="target_version" value="<?php echo htmlOutput($remoteInfo['version']); ?>">
                            <button type="submit" class="btn btn-success" onclick="return confirm('确定要安装 v<?php echo htmlOutput($remoteInfo['version']); ?> 吗？\n\n更新过程中系统将自动备份文件，如遇问题可回滚。\n\n建议更新前手动备份数据库。');">
                                <?php echo iconSVG('update'); ?> 立即更新到 v<?php echo htmlOutput($remoteInfo['version']); ?>
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>

                    <?php if ($updateAvailable && $remoteInfo): ?>
                    <div class="update-changelog" style="margin-top: 20px;">
                        <div class="update-changelog-title">v<?php echo htmlOutput($remoteInfo['version']); ?> 更新内容</div>
                        <?php if (isset($remoteInfo['release_date'])): ?>
                        <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 10px;">
                            发布日期: <?php echo htmlOutput($remoteInfo['release_date']); ?>
                        </div>
                        <?php endif; ?>
                        <?php if (isset($remoteInfo['changelog']) && is_array($remoteInfo['changelog'])): ?>
                        <ul class="update-changelog-list">
                            <?php foreach ($remoteInfo['changelog'] as $item): ?>
                            <li><?php echo htmlOutput($item); ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <?php endif; ?>
                        <?php if (isset($remoteInfo['description'])): ?>
                        <div style="font-size: 13px; color: var(--text-primary); margin-top: 8px;">
                            <?php echo htmlOutput($remoteInfo['description']); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>

                <hr style="border: none; border-top: 1px solid var(--border-color); margin: 24px 0;">

                <!-- 手动上传更新 -->
                <div class="update-section">
                    <div class="update-section-title">手动上传更新包</div>
                    <p class="update-section-desc">如果在线更新不可用，可以直接上传更新包（.zip 格式）进行更新。</p>
                    <form method="post" enctype="multipart/form-data" style="margin-top: 12px;">
                        <input type="hidden" name="action" value="upload">
                        <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
                            <input type="file" name="update_package" accept=".zip" required
                                   style="flex: 1; min-width: 220px;">
                            <button type="submit" class="btn btn-primary"
                                    onclick="return confirm('确定要上传并安装此更新包吗？\n\n系统将自动备份受影响文件。');">
                                <?php echo iconSVG('update'); ?> 上传并更新
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- 更新历史 -->
        <div class="card" style="margin-top: 24px;">
            <div class="card-header">
                <span style="font-weight: 600;">更新历史</span>
            </div>
            <div class="card-body">
                <?php if ($historyResult && mysqli_num_rows($historyResult) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>更新前</th>
                                <th>更新后</th>
                                <th>状态</th>
                                <th>文件数</th>
                                <th>SQL</th>
                                <th>时间</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($historyResult)): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td>v<?php echo htmlOutput($row['from_version']); ?></td>
                                <td>v<?php echo htmlOutput($row['to_version']); ?></td>
                                <td>
                                    <?php if ($row['status'] == 'success'): ?>
                                    <span class="badge badge-success">成功</span>
                                    <?php elseif ($row['status'] == 'failed'): ?>
                                    <span class="badge badge-danger">失败</span>
                                    <?php else: ?>
                                    <span class="badge badge-warning">已回滚</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $row['file_count']; ?></td>
                                <td><?php echo $row['sql_executed'] ? '是' : '否'; ?></td>
                                <td><?php echo htmlOutput($row['created_at']); ?></td>
                                <td>
                                    <button class="btn btn-secondary btn-sm"
                                            onclick="showLogDetail(<?php echo $row['id']; ?>)"
                                            title="查看详情">详情</button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div style="text-align: center; padding: 40px; color: var(--text-secondary);">
                    <div style="font-size: 48px; margin-bottom: 12px;">
                        <?php echo iconSVG('clipboard'); ?>
                    </div>
                    <p>暂无更新记录</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- 更新日志详情弹窗 -->
        <?php
        // 重新获取数据用于弹窗
        mysqli_data_seek($historyResult, 0);
        ?>
        <?php while ($row = mysqli_fetch_assoc($historyResult)): ?>
        <div class="modal" id="logModal_<?php echo $row['id']; ?>" style="display: none;">
            <div class="modal-content" style="max-width: 600px;">
                <div class="modal-header">
                    <h3>更新日志 #<?php echo $row['id']; ?></h3>
                    <button class="close-btn" onclick="closeLogModal(<?php echo $row['id']; ?>)">&times;</button>
                </div>
                <div class="modal-body">
                    <div style="margin-bottom: 12px;">
                        <strong>版本:</strong> v<?php echo htmlOutput($row['from_version']); ?> → v<?php echo htmlOutput($row['to_version']); ?>
                    </div>
                    <div style="margin-bottom: 12px;">
                        <strong>状态:</strong> <?php echo $row['status'] == 'success' ? '成功' : ($row['status'] == 'failed' ? '失败' : '已回滚'); ?>
                    </div>
                    <div style="margin-bottom: 12px;">
                        <strong>时间:</strong> <?php echo htmlOutput($row['created_at']); ?>
                    </div>
                    <div style="margin-bottom: 12px;">
                        <strong>备份路径:</strong> <?php echo htmlOutput($row['backup_path'] ?: '无'); ?>
                    </div>
                    <div style="margin-bottom: 12px;">
                        <strong>IP:</strong> <?php echo htmlOutput($row['ip_address']); ?>
                    </div>
                    <div style="background: var(--bg); padding: 12px; border-radius: 8px; max-height: 300px; overflow-y: auto;">
                        <strong>详细日志:</strong>
                        <pre style="white-space: pre-wrap; font-size: 12px; margin-top: 8px; color: var(--text-secondary);"><?php echo htmlOutput($row['log_message']); ?></pre>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>

        <!-- 配置提示卡片 -->
        <?php if (UPDATE_API_URL && strpos(UPDATE_API_URL, 'YOUR_USERNAME') !== false): ?>
        <div class="card" style="margin-top: 24px; border-color: var(--warning); background: #FFFBEB;">
            <div class="card-header" style="color: var(--warning);">
                <?php echo iconSVG('settings'); ?> 配置提醒
            </div>
            <div class="card-body">
                <p style="font-size: 13px; color: var(--text-secondary); margin: 0;">
                    更新服务器地址尚未配置。请按以下步骤完成配置：
                </p>
                <ol style="font-size: 13px; color: var(--text-secondary); margin: 8px 0 0 0; padding-left: 20px;">
                    <li>将更新包上传到你的服务器或 GitHub Releases</li>
                    <li>创建 <code>update_info.json</code> 文件，描述最新版本信息</li>
                    <li>在 <code>admin/db_config.php</code> 中修改 <code>UPDATE_API_URL</code> 常量</li>
                    <li>或者使用本页面的"手动上传更新包"功能</li>
                </ol>
            </div>
        </div>
        <?php endif; ?>
    </div>

<script>
function showLogDetail(id) {
    var modal = document.getElementById('logModal_' + id);
    if (modal) {
        modal.style.display = 'flex';
    }
}

function closeLogModal(id) {
    var modal = document.getElementById('logModal_' + id);
    if (modal) {
        modal.style.display = 'none';
    }
}

// 点击模态框背景关闭
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        e.target.style.display = 'none';
    }
});
</script>

<?php renderFooter(); ?>
</body>
</html>
