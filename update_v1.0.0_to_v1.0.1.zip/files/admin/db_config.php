<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_USER', 'yd.wd12.pw');
define('DB_PASS', 'Z4hKt3ZGSBmJyGrh');
define('DB_NAME', 'yd.wd12.pw');

// 系统版本号（格式: 主版本.次版本.修订号）
define('SYSTEM_VERSION', '1.0.0');

// 更新服务器配置（修改为你的实际服务器地址）
// 示例: GitHub Releases API 或你自己的服务器 JSON 接口
define('UPDATE_API_URL', 'https://github.com/ylctoo/my-nav-updates/blob/main/update_info.json');
// 也可以通过后台设置动态配置更新地址，此处为默认值

// 建立数据库连接
function getDBConnection() {
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (!$conn) {
        die('数据库连接失败: ' . mysqli_connect_error());
    }
    mysqli_set_charset($conn, 'utf8mb4');
    return $conn;
}

// 检查登录状态
function checkLogin() {
    session_start();
    if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_username'])) {
        header('Location: ../admin/login.php');
        exit();
    }
}

// 自动给 admin_users 表添加 group_id 和 is_super 字段
function ensureAdminUserColumns($conn) {
    $check = mysqli_query($conn, "SHOW COLUMNS FROM admin_users LIKE 'group_id'");
    if ($check && mysqli_num_rows($check) == 0) {
        @mysqli_query($conn, "ALTER TABLE admin_users ADD COLUMN group_id INT DEFAULT NULL");
    }
    $check2 = mysqli_query($conn, "SHOW COLUMNS FROM admin_users LIKE 'is_super'");
    if ($check2 && mysqli_num_rows($check2) == 0) {
        @mysqli_query($conn, "ALTER TABLE admin_users ADD COLUMN is_super TINYINT(1) DEFAULT 0");
    }
    // 将 id=1 的 admin 设为超级管理员
    @mysqli_query($conn, "UPDATE admin_users SET is_super = 1 WHERE id = 1");
}

// 判断当前登录用户是否为超级管理员
function isSuperAdmin() {
    return isset($_SESSION['is_super']) && $_SESSION['is_super'] == 1;
}

// 获取所有后台菜单项（供权限设置页面使用）
function getAllMenus() {
    return [
        'index' => ['icon' => 'dashboard', 'text' => '首页', 'href' => 'index.php'],
        'settings' => ['icon' => 'settings', 'text' => '基础设置', 'href' => 'settings.php'],
        'template' => ['icon' => 'palette', 'text' => '模板选择', 'href' => 'template.php'],
        'categories' => ['icon' => 'folder', 'text' => '导航分类', 'href' => 'categories.php'],
        'links' => ['icon' => 'link', 'text' => '导航链接', 'href' => 'links.php'],
        'carousel' => ['icon' => 'image', 'text' => '轮播图广告', 'href' => 'carousel.php'],
        'lottery' => ['icon' => 'gift', 'text' => '抽奖设置', 'href' => 'lottery.php'],
        'users' => ['icon' => 'users', 'text' => '会员管理', 'href' => 'users.php'],
        'sidebuttons' => ['icon' => 'smartphone', 'text' => '侧边按钮', 'href' => 'sidebuttons.php'],
        'contacts' => ['icon' => 'phone', 'text' => '联系方式', 'href' => 'contacts.php'],
        'scroll_notices' => ['icon' => 'scroll', 'text' => '滚动公告', 'href' => 'scroll_notices.php'],
        'popup_notice' => ['icon' => 'megaphone', 'text' => '弹窗公告', 'href' => 'popup_notice.php'],
        'stats' => ['icon' => 'chart', 'text' => '网站统计', 'href' => 'stats.php'],
        'update' => ['icon' => 'update', 'text' => '系统更新', 'href' => 'update.php'],
        'password' => ['icon' => 'lock', 'text' => '修改密码', 'href' => 'password.php'],
    ];
}

// 获取当前用户允许显示的菜单key列表（超级管理员返回全部）
function getAllowedMenus() {
    if (isSuperAdmin()) {
        return array_keys(getAllMenus());
    }
    $conn = getDBConnection();
    $groupId = isset($_SESSION['group_id']) ? intval($_SESSION['group_id']) : 0;
    $allowed = [];
    if ($groupId > 0) {
        $result = mysqli_query($conn, "SELECT menus FROM admin_groups WHERE id = $groupId");
        if ($result && $row = mysqli_fetch_assoc($result)) {
            $menus = $row['menus'];
            if ($menus) {
                $allowed = explode(',', $menus);
                $allowed = array_map('trim', $allowed);
            }
        }
    }
    mysqli_close($conn);
    return $allowed;
}

// 安全输出HTML
function htmlOutput($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

// 自动创建 scroll_notices 表
function ensureScrollNoticesTable($conn) {
    $sql = "CREATE TABLE IF NOT EXISTS scroll_notices (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(100) DEFAULT '',
        platform_name VARCHAR(100) DEFAULT '',
        score VARCHAR(50) DEFAULT '',
        username_color VARCHAR(20) DEFAULT '#ffffff',
        platform_color VARCHAR(20) DEFAULT '#ffffff',
        score_color VARCHAR(20) DEFAULT '#fbbf24',
        sort_order INT DEFAULT 0,
        enabled TINYINT(1) DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    @mysqli_query($conn, $sql);
}

// 自动创建 popup_notices 表
function ensurePopupNoticesTable($conn) {
    $sql = "CREATE TABLE IF NOT EXISTS popup_notices (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) DEFAULT '',
        content TEXT,
        enabled TINYINT(1) DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    @mysqli_query($conn, $sql);
}

// 确保 settings 表有 system_version 字段
function ensureSystemVersionColumn($conn) {
    $check = mysqli_query($conn, "SHOW COLUMNS FROM settings LIKE 'system_version'");
    if ($check && mysqli_num_rows($check) == 0) {
        @mysqli_query($conn, "ALTER TABLE settings ADD COLUMN system_version VARCHAR(20) DEFAULT '1.0.0'");
    }
    // 如果字段值为空或NULL，写入默认版本号
    @mysqli_query($conn, "UPDATE settings SET system_version = '1.0.0' WHERE system_version IS NULL OR system_version = ''");
}

// 创建更新日志表
function ensureUpdateLogTable($conn) {
    $sql = "CREATE TABLE IF NOT EXISTS update_log (
        id INT AUTO_INCREMENT PRIMARY KEY,
        from_version VARCHAR(20) DEFAULT '',
        to_version VARCHAR(20) DEFAULT '',
        status ENUM('success','failed','rolled_back') DEFAULT 'success',
        log_message TEXT,
        file_count INT DEFAULT 0,
        sql_executed TINYINT(1) DEFAULT 0,
        backup_path VARCHAR(500) DEFAULT '',
        ip_address VARCHAR(50) DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    @mysqli_query($conn, $sql);
}

// 获取远程更新信息
function fetchRemoteUpdateInfo($url = '') {
    if (empty($url)) {
        $url = UPDATE_API_URL;
    }
    if (empty($url) || strpos($url, 'YOUR_USERNAME') !== false) {
        return ['error' => '更新服务器地址未配置，请在 db_config.php 中设置 UPDATE_API_URL'];
    }
    
    $ctx = stream_context_create([
        'http' => [
            'timeout' => 15,
            'user_agent' => 'NavigationSystem-Update/1.0',
            'ignore_errors' => true
        ],
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false
        ]
    ]);
    
    $content = @file_get_contents($url, false, $ctx);
    if ($content === false) {
        return ['error' => '无法连接到更新服务器，请检查网络或服务器地址'];
    }
    
    $data = json_decode($content, true);
    if ($data === null) {
        return ['error' => '更新信息格式错误，无法解析JSON'];
    }
    
    return $data;
}

// 比较版本号大小
function versionCompare($v1, $v2) {
    $parts1 = array_map('intval', explode('.', $v1));
    $parts2 = array_map('intval', explode('.', $v2));
    $max = max(count($parts1), count($parts2));
    $parts1 = array_pad($parts1, $max, 0);
    $parts2 = array_pad($parts2, $max, 0);
    for ($i = 0; $i < $max; $i++) {
        if ($parts1[$i] > $parts2[$i]) return 1;
        if ($parts1[$i] < $parts2[$i]) return -1;
    }
    return 0;
}

// 递归备份目录中的文件
function backupFiles($sourceDir, $backupDir, $filesList = null) {
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0777, true);
    }
    $backedUp = [];
    if ($filesList && is_array($filesList)) {
        foreach ($filesList as $file) {
            $src = rtrim($sourceDir, '/') . '/' . ltrim($file, '/');
            $dst = rtrim($backupDir, '/') . '/' . ltrim($file, '/');
            if (file_exists($src)) {
                $dstDir = dirname($dst);
                if (!is_dir($dstDir)) {
                    mkdir($dstDir, 0777, true);
                }
                if (copy($src, $dst)) {
                    $backedUp[] = $file;
                }
            }
        }
    }
    return $backedUp;
}

// 分页函数
function paginate($page, $total, $perPage = 10, $url = '') {
    $pages = ceil($total / $perPage);
    if ($pages <= 1) return '';
    $html = '<div class="pagination">';
    if ($page > 1) {
        $html .= "<a href=\"{$url}page=" . ($page - 1) . "\">上一页</a>";
    }
    for ($i = 1; $i <= $pages; $i++) {
        if ($i == $page) {
            $html .= "<span class=\"active\">{$i}</span>";
        } else {
            $html .= "<a href=\"{$url}page={$i}\">{$i}</a>";
        }
    }
    if ($page < $pages) {
        $html .= "<a href=\"{$url}page=" . ($page + 1) . "\">下一页</a>";
    }
    $html .= '</div>';
    return $html;
}
?>