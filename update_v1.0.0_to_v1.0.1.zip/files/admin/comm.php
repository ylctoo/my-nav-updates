<?php
/**
 * 后台公共函数文件
 * 包含所有页面的公共部分，方便统一维护
 */

// 引入数据库配置
include_once('db_config.php');

// 自动执行数据库迁移（每次请求检查并补全缺失的表/字段）
$__autoConn = getDBConnection();
ensureAdminUserColumns($__autoConn);
ensureScrollNoticesTable($__autoConn);
ensurePopupNoticesTable($__autoConn);
ensureSystemVersionColumn($__autoConn);
ensureUpdateLogTable($__autoConn);
mysqli_close($__autoConn);

/**
 * 输出一套线性 SVG 图标（Lucide 风格，stroke=currentColor，可随文字颜色变化）
 * @param string $key 图标语义名，见下方 $paths 映射
 * @return string 完整 <svg> 字符串；未知 key 返回占位圆点
 */
function iconSVG($key) {
    $paths = [
        'dashboard' => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/>',
        'settings'  => '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
        'palette'   => '<circle cx="13.5" cy="6.5" r=".6" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".6" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".6" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".6" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c1.7 0 3-1.3 3-3 0-.7-.2-1.3-.6-1.8-.3-.5-.6-1.1-.6-1.7 0-1.1.9-2 2-2h1.5c2.2 0 4-1.8 4-4 0-4.4-4.5-8-10-8z"/>',
        'folder'    => '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
        'link'      => '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
        'image'     => '<rect x="3" y="3" width="18" height="18" rx="2.5"/><circle cx="8.5" cy="8.5" r="1.6"/><path d="M21 15.5l-5-5L5 21"/>',
        'gift'      => '<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M5 12v9h14v-9"/><path d="M5 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM19 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/><line x1="12" y1="8" x2="12" y2="5"/>',
        'users'     => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
        'smartphone'=> '<rect x="6" y="2" width="12" height="20" rx="2.5"/><line x1="12" y1="18" x2="12" y2="18"/>',
        'phone'     => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2 3.2 2 2 0 0 1 4.1 1h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7A2 2 0 0 1 22 16.9z"/>',
        'scroll'    => '<path d="M4 4h13a2 2 0 0 1 2 2v0a2 2 0 0 1-2 2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12"/><path d="M8 8h9M8 12h9"/>',
        'megaphone' => '<path d="M3 11v2a1 1 0 0 0 1 1h2l5 4V6L6 10H4a1 1 0 0 0-1 1z"/><path d="M15 8a4 4 0 0 1 0 8"/><line x1="19" y1="6" x2="19" y2="18"/>',
        'chart'     => '<line x1="6" y1="20" x2="6" y2="12"/><line x1="12" y1="20" x2="12" y2="6"/><line x1="18" y1="20" x2="18" y2="10"/>',
        'lock'      => '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
        'shield'    => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
        'user'      => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'external'  => '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>',
        'menu'      => '<rect x="3" y="4" width="18" height="16" rx="2.5"></rect><line x1="9" y1="4" x2="9" y2="20"></line><polyline points="15.5 14.5 13.5 12 15.5 9.5"></polyline>',
        'panel-left' => '<rect x="3" y="4" width="18" height="16" rx="2.5"/><line x1="9" y1="4" x2="9" y2="20"/><polyline points="15.5 14.5 13.5 12 15.5 9.5"/>',
        'eye'       => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
        'calendar'  => '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
        'globe'     => '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
        'monitor'   => '<rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>',
        'flame'     => '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.4-.5-2.1-1.5-3.5C8 10.5 7 11.5 7 13a3 3 0 0 0 6 0c0-3.5-2.5-6-4-8.5 2 .5 5 3 5 8.5a4 4 0 0 1-8 0c0-1.5.5-2.5 1.5-3.5Z"/>',
        'trophy'    => '<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.7V22M14 14.7V22"/><path d="M6 9v3.5a4 4 0 0 0 4 4h4a4 4 0 0 0 4-4V9"/>',
        'clipboard' => '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>',
        'refresh'   => '<path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/>',
        'trash'     => '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
        'carousel'  => '<rect x="2" y="4" width="20" height="16" rx="2"/><circle cx="12" cy="12" r="2"/><path d="M8 8h0M16 8h0"/>',
        'update'    => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
    ];
    $inner = isset($paths[$key]) ? $paths[$key] : '<circle cx="12" cy="12" r="1.6" fill="currentColor"/>';
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $inner . '</svg>';
}

/**
 * 渲染HTML头部
 * @param string $title 页面标题
 */
function renderHeader($title = '后台管理系统') {
    echo '<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>' . $title . '</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>';
}

/**
 * 渲染侧边栏
 * @param string $activePage 当前页面标识，用于高亮菜单
 */
function renderSidebar($activePage = 'index') {
    $menus = getAllMenus();
    // "前往首页"始终显示
    $menus['shouye'] = ['icon' => 'external', 'text' => '前往首页', 'href' => '/'];
    
    // 超级管理员额外显示"权限设置"和"管理员"
    $superAdmin = isSuperAdmin();
    if ($superAdmin) {
        $menus['permissions'] = ['icon' => 'shield', 'text' => '权限设置', 'href' => 'permissions.php'];
        $menus['administrators'] = ['icon' => 'user', 'text' => '管理员', 'href' => 'administrators.php'];
    }
    
    // 非超级管理员：根据用户组过滤菜单
    if (!$superAdmin) {
        $allowed = getAllowedMenus();
        // 修改密码和前往首页始终可见
        $allowed[] = 'password';
        $allowed[] = 'shouye';
        $filtered = [];
        foreach ($menus as $key => $menu) {
            if (in_array($key, $allowed)) {
                $filtered[$key] = $menu;
            }
        }
        $menus = $filtered;
    }
    
    // 分组导航（按功能域分组，贴近 SaaS 后台风格）
    $groups = [
        '经营' => ['index', 'stats', 'users'],
        '内容' => ['template', 'categories', 'links', 'carousel', 'sidebuttons'],
        '运营' => ['lottery', 'contacts', 'scroll_notices', 'popup_notice'],
        '系统' => ['settings', 'permissions', 'administrators', 'update', 'password'],
        '快捷' => ['shouye'],
    ];

    echo '<aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <div class="brand-text">
                <div class="brand-title">微云网络导航系统</div>
                <div class="brand-sub">让导航管理更高效</div>
            </div>
            <button class="brand-toggle" id="sidebarToggleBrand" title="展开 / 收起侧边栏" aria-label="展开或收起侧边栏">' . iconSVG('panel-left') . '</button>
        </div>
        <nav class="sidebar-nav">';
    
    foreach ($groups as $groupTitle => $keys) {
        $items = [];
        foreach ($keys as $k) {
            if (isset($menus[$k])) {
                $items[$k] = $menus[$k];
            }
        }
        if (empty($items)) {
            continue;
        }
        echo '<div class="nav-group">
            <div class="nav-group-title">' . $groupTitle . '</div>
            <ul class="menu">';
        foreach ($items as $key => $menu) {
            $activeClass = ($key == $activePage) ? ' class="active"' : '';
            $target = ($key == 'shouye') ? ' target="_blank"' : '';
            echo '<li><a href="' . $menu['href'] . '"' . $activeClass . $target . '>'
               . '<span class="menu-icon">' . iconSVG($menu['icon']) . '</span>'
               . '<span class="menu-text">' . $menu['text'] . '</span></a></li>';
        }
        echo '</ul></div>';
    }
    
    echo '</nav></aside>';
}

/**
 * 渲染顶部导航栏
 * @param string $title 标题文字
 */
function renderTopbar($title = '后台管理') {
    // 获取当前用户名
    $username = 'admin';
    if (isset($_SESSION['admin_username'])) {
        $username = $_SESSION['admin_username'];
    }
    
    echo '<div class="topbar">
        <div class="title" id="sidebarToggle" title="点击展开/收起侧边栏"><button class="brand-toggle" id="sidebarToggleBrand" title="展开 / 收起侧边栏" aria-label="展开或收起侧边栏">' . iconSVG('menu') . '</button><span>' . $title . '</span></div>
        <div class="user-info">
            <div class="avatar">' . mb_substr($username, 0, 1, 'UTF-8') . '</div>
            <button class="user-name-btn" id="userNameBtn">' . $username . '</button>
            <a href="logout.php">退出登录</a>
        </div>
    </div>';
}

/**
 * 渲染密码修改模态框
 */
function renderPasswordModal() {
    echo '<!-- 密码修改模态框 -->
    <div class="modal" id="changePasswordModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>修改密码</h3>
                <button class="close-btn" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                <form method="POST" action="">
                    <div class="form-group">
                        <label>当前密码</label>
                        <input type="password" name="old_password" required placeholder="请输入当前密码">
                    </div>
                    <div class="form-group">
                        <label>新密码</label>
                        <input type="password" name="new_password" required placeholder="请输入新密码（至少6位）">
                    </div>
                    <div class="form-group">
                        <label>确认新密码</label>
                        <input type="password" name="confirm_password" required placeholder="请再次输入新密码">
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn btn-secondary" onclick="closeModal()">取消</button>
                        <button type="submit" class="btn btn-primary">确认修改</button>
                    </div>
                </form>
            </div>
        </div>
    </div>';
}

/**
 * 渲染页面底部（包含侧边栏切换JS）
 */
function renderFooter() {
    echo '<script>
        // 侧边栏展开/收起功能
        function toggleSidebar() {
            var sidebar = document.getElementById("sidebar");
            var content = document.querySelector(".content");
            var topbar = document.querySelector(".topbar");
            var isMobile = window.innerWidth <= 768;
            
            if (isMobile) {
                // 手机端逻辑
                if (sidebar.classList.contains("active")) {
                    // 从完全展开变为显示一半
                    sidebar.classList.remove("active");
                    sidebar.classList.add("collapsed");
                } else if (sidebar.classList.contains("collapsed")) {
                    // 从显示一半变为完全展开
                    sidebar.classList.remove("collapsed");
                    sidebar.classList.add("active");
                } else {
                    // 初始隐藏状态，先显示一半
                    sidebar.classList.add("collapsed");
                }
            } else {
                // 电脑端逻辑
                if (sidebar.classList.contains("collapsed")) {
                    // 展开侧边栏
                    sidebar.classList.remove("collapsed");
                    if (content) content.classList.remove("expanded");
                    if (topbar) topbar.classList.remove("expanded");
                } else {
                    // 收起侧边栏
                    sidebar.classList.add("collapsed");
                    if (content) content.classList.add("expanded");
                    if (topbar) topbar.classList.add("expanded");
                }
            }
        }
        
        // 点击标题 / 品牌区按钮 切换侧边栏
        ["sidebarToggle", "sidebarToggleBrand"].forEach(function (id) {
            var el = document.getElementById(id);
            if (el) {
                el.addEventListener("click", toggleSidebar);
            }
        });
    </script>';
}

/**
 * 渲染页面底部（简化版，不含模态框JS）
 */
function renderFooterSimple() {
    echo '</body>
</html>';
}

/**
 * 处理密码修改请求
 * @return array ['success' => bool, 'message' => string]
 */
function handlePasswordChange() {
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['old_password'])) {
        $conn = getDBConnection();
        $old_password = trim($_POST['old_password']);
        $new_password = trim($_POST['new_password']);
        $confirm_password = trim($_POST['confirm_password']);
        
        $admin_id = $_SESSION['admin_id'];
        $sql = "SELECT * FROM admin_users WHERE id = $admin_id";
        $result = mysqli_query($conn, $sql);
        
        if ($row = mysqli_fetch_assoc($result)) {
            if (!password_verify($old_password, $row['password'])) {
                mysqli_close($conn);
                return ['success' => false, 'message' => '当前密码不正确'];
            } elseif ($new_password != $confirm_password) {
                mysqli_close($conn);
                return ['success' => false, 'message' => '两次输入的新密码不一致'];
            } elseif (strlen($new_password) < 6) {
                mysqli_close($conn);
                return ['success' => false, 'message' => '新密码长度至少6位'];
            } else {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update_sql = "UPDATE admin_users SET password = '$hashed_password' WHERE id = $admin_id";
                if (mysqli_query($conn, $update_sql)) {
                    mysqli_close($conn);
                    $_POST = array();
                    return ['success' => true, 'message' => '密码修改成功，请重新登录'];
                } else {
                    $error = mysqli_error($conn);
                    mysqli_close($conn);
                    return ['success' => false, 'message' => '密码修改失败: ' . $error];
                }
            }
        }
        mysqli_close($conn);
    }
    return null;
}
